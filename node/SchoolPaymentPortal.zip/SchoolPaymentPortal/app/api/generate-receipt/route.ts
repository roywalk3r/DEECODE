import { NextResponse } from 'next/server'
import { getServerSession } from 'next-auth/next'
import prisma from '@/lib/prisma'
import { sendEmail } from '@/lib/email'
import { authOptions } from '../auth/[...nextauth]/route'

export async function POST(req: Request) {
  const session = await getServerSession(authOptions)

  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  const { paymentId } = await req.json()

  const payment = await prisma.payment.findUnique({
    where: { id: paymentId },
    include: { user: true },
  })

  if (!payment) {
    return NextResponse.json({ error: 'Payment not found' }, { status: 404 })
  }

  // Generate receipt content
  const receiptContent = `
    Receipt for Payment
    -------------------
    Student: ${payment.user.name}
    Amount: $${payment.amount}
    Date: ${payment.createdAt.toLocaleDateString()}
    Description: ${payment.description}
    Status: ${payment.status}
  `

  // Send receipt via email
  await sendEmail(payment.user.email, 'Payment Receipt', receiptContent)

  // You could also generate a PDF here and attach it to the email

  return NextResponse.json({ success: true })
}

