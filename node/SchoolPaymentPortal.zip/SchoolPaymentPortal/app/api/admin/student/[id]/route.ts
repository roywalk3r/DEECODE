import { NextResponse } from 'next/server'
import { getServerSession } from 'next-auth/next'
import prisma from '@/lib/prisma'
import { authOptions } from '../../../auth/[...nextauth]/route'

export async function GET(
  req: Request,
  { params }: { params: { id: string } }
) {
  const session = await getServerSession(authOptions)

  if (!session || session.user.role !== 'ADMIN') {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  const student = await prisma.user.findUnique({
    where: { id: params.id },
    include: { payments: true },
  })

  if (!student) {
    return NextResponse.json({ error: 'Student not found' }, { status: 404 })
  }

  const totalPaid = student.payments.reduce((sum, payment) => sum + payment.amount, 0)
  const totalFees = 10000 // This should be fetched from a configuration or calculated
  const pendingBalance = totalFees - totalPaid

  return NextResponse.json({
    id: student.id,
    name: student.name,
    email: student.email,
    totalPaid,
    pendingBalance,
  })
}

