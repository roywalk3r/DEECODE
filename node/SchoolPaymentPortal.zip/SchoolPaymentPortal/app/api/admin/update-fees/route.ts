import { NextResponse } from 'next/server'
import { getServerSession } from 'next-auth/next'
import prisma from '@/lib/prisma'
import { authOptions } from '../../auth/[...nextauth]/route'

export async function POST(req: Request) {
  const session = await getServerSession(authOptions)

  if (!session || session.user.role !== 'ADMIN') {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  const { fees } = await req.json()

  // In a real-world scenario, you might want to store this in a separate table
  // For simplicity, we'll update a global setting
  await prisma.setting.upsert({
    where: { key: 'school_fees' },
    update: { value: fees.toString() },
    create: { key: 'school_fees', value: fees.toString() },
  })

  return NextResponse.json({ success: true })
}

