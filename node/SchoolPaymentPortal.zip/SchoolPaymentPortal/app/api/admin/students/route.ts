import { NextResponse } from 'next/server'
import { getServerSession } from 'next-auth/next'
import prisma from '@/lib/prisma'
import { authOptions } from '../../auth/[...nextauth]/route'

export async function GET() {
  const session = await getServerSession(authOptions)

  if (!session || session.user.role !== 'ADMIN') {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  const students = await prisma.user.findMany({
    where: { role: 'STUDENT' },
    include: { payments: true },
  })

  const studentsWithPaymentInfo = students.map(student => {
    const totalPaid = student.payments.reduce((sum, payment) => sum + payment.amount, 0)
    const totalFees = 10000 // This should be fetched from a configuration or calculated
    const pendingBalance = totalFees - totalPaid

    return {
      id: student.id,
      name: student.name,
      email: student.email,
      totalPaid,
      pendingBalance,
    }
  })

  return NextResponse.json(studentsWithPaymentInfo)
}

