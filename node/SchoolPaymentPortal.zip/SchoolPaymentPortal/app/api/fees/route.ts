import { NextResponse } from 'next/server'
import { getServerSession } from 'next-auth/next'
import prisma from '@/lib/prisma'
import { authOptions } from '../auth/[...nextauth]/route'

export async function GET() {
  const session = await getServerSession(authOptions)

  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  const payments = await prisma.payment.findMany({
    where: {
      userId: session.user.id,
    },
  })

  const totalFees = 10000 // This should be fetched from a configuration or calculated
  const paidAmount = payments.reduce((sum, payment) => sum + payment.amount, 0)
  const pendingBalance = totalFees - paidAmount

  return NextResponse.json({ totalFees, pendingBalance })
}

