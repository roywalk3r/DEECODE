// ... (previous code remains the same)

<h3 className="text-lg font-semibold mt-4 mb-2">Payment History</h3>
<ul className="divide-y divide-gray-200">
  {payments.map((payment) => (
    <li key={payment.id} className="py-4 flex flex-col sm:flex-row sm:justify-between">
      <div className="text-sm font-medium text-gray-900">{payment.description}</div>
      <div className="mt-1 sm:mt-0 text-sm text-gray-600 flex justify-between sm:justify-start">
        <span className="sm:mr-4">${payment.amount}</span>
        <span>{payment.status}</span>
      </div>
    </li>
  ))}
</ul>

// ... (rest of the code remains the same)

