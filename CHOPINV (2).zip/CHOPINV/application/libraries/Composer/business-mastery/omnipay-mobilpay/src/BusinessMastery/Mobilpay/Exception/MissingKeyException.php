<?php namespace Omnipay\MobilPay\Exception;

class MissingKeyException extends \Exception{}