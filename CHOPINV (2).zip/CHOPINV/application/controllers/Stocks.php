<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Stocks extends MY_Controller {
    /**
     * Stocks constructor.
     */
    public function __construct ()
    {
        parent::__construct ();
        // Load Todo Model
        $this->load->model ( 'stocks_model' );
        // Load Form Validation Library
        $this->load->library ( 'form_validation' );
        // Load Ion Auth Library
        $this->load->library ( 'ion_auth' );
        // Load Helper Language
        $this->load->helper('language');
        // Load Helper Date Format
        $this->load->helper('date_format');
        // Check user is logged in ?
        if ( !$this->ion_auth->logged_in () ) {
            if ($this->input->is_ajax_request()) {
                $next_link = urlencode("/stocks");
                $result = array("status"=>"redirect", "message"=>site_url("auth/login?next=$next_link"));
                die(json_encode($result));
            }else{
                $next_link = urlencode(substr("$_SERVER[REQUEST_URI]", stripos("$_SERVER[REQUEST_URI]", "index.php")+9));
                redirect("auth/login?next=$next_link");
            }
        }
    }

    public function index()
    {
        $data['message']          = (validation_errors()) ? validation_errors() : $this->session->flashdata('message');
        $data['success_message']  = $this->session->flashdata('success_message');
        $meta['page_title']       = "Stocks";
        $data['page_title']       = "Stocks";

        $this->load->view ( 'templates/head' , $meta );
        $this->load->view ( 'templates/header' );
        $this->load->view ( 'stocks/index' , $data );
        $this->load->view ( 'templates/footer' , $meta );
    }
    public function getData() {
        // Check if it's an AJAX request
        if (!$this->input->is_ajax_request()) {
            $result = array("status" => "error", "message" => lang("access_denied"));
            $this->output->set_content_type('application/json')->set_output(json_encode($result));
            return false;
        }
    
        // Load the Stocks model
        
        // Fetch the data from the model
        $stock_data = $this->stocks_model->getAll();
    
        // Organize the data by categories
        $organized_data = [
            'trunk_and_chopbox' => [],
            'drinks' => [],
            'water' => []
        ];
    
        // Iterate over the stock data and group them by category
        // foreach ($stock_data as $stock) {
        //     if (in_array($stock['category'], ['trunk_and_chopbox', 'drinks', 'water'])) {
        //         $organized_data[$stock['category']][] = $stock;
        //     }
        // }
    
        // Return the organized data as JSON
        // $this->output->set_content_type('application/json')->set_output(json_encode($organized_data));
        $this->output->set_content_type('application/json')->set_output(json_encode($stock_data));
    }
    
  
   
    public function updateQuantity()
    {
        if (!$this->input->is_ajax_request()) {
            $response = array('status' => 'error', 'message' => 'Access Denied');
            $this->output->set_content_type('application/json')->set_output(json_encode($response));
            return;
        }
    
        $item_id = $this->input->post('item_id');
        $new_quantity = $this->input->post('quantity'); // New stock to be added
    
        if (!$item_id || $new_quantity === null) {
            $response = array('status' => 'error', 'message' => 'Invalid input');
            $this->output->set_content_type('application/json')->set_output(json_encode($response));
            return;
        }
    
        // Get current stock details
        $stock = $this->stocks_model->getStockById($item_id);
    
        if ($stock) {
            $previous_quantity = $stock['quantity'];
    
            // Check if previous quantity is negative
            if ($previous_quantity < 0 && $new_quantity > 0) {
                // Subtract the negative stock from the new stock
                $updated_quantity = $new_quantity + $previous_quantity;
    
                // Ensure the stock does not go negative again if subtraction leaves it below zero
                if ($updated_quantity < 0) {
                    $response = array('status' => 'error', 'message' => 'New stock insufficient to cover negative balance.');
                    $this->output->set_content_type('application/json')->set_output(json_encode($response));
                    return;
                }
            } else {
                // If the previous quantity is not negative, update with new quantity directly
                $updated_quantity = $new_quantity;
            }
    
            // Update stock quantity in the stocks table
            $this->db->set('quantity', $updated_quantity);
            $this->db->where('item_id', $item_id);
            $update_result = $this->db->update('stocks');
    
            if ($update_result) {
                // Insert a record into stock_history to track the change
                $stock_history_data = array(
                    'item_id' => $item_id,
                    'previous_quantity' => $previous_quantity,
                    'new_quantity' => $updated_quantity,
                    'updated_by' => $this->ion_auth->user()->row()->username,
                    'updated_at' => date('Y-m-d H:i:s')  // Add timestamp to the stock history record
                );
                $this->db->insert('stock_history', $stock_history_data);
    
                // Return success response
                $response = array('status' => 'success', 'message' => 'Quantity updated successfully');
            } else {
                $response = array('status' => 'error', 'message' => 'Failed to update stock quantity');
            }
        } else {
            $response = array('status' => 'error', 'message' => 'Stock not found');
        }
    
        $this->output->set_content_type('application/json')->set_output(json_encode($response));
    }
    
    

    // public function updateQuantity()
    // {
    //     if (!$this->input->is_ajax_request()) {
    //         $response = array('status' => 'error', 'message' => 'Access Denied');
    //         $this->output->set_content_type('application/json')->set_output(json_encode($response));
    //         return;
    //     }
    
    //     $item_id = $this->input->post('item_id');
    //     $new_quantity = $this->input->post('quantity');
    
    //     if (!$item_id || $new_quantity === null) {
    //         $response = array('status' => 'error', 'message' => 'Invalid input');
    //         $this->output->set_content_type('application/json')->set_output(json_encode($response));
    //         return;
    //     }
    
    //     // Get current stock details
    //     $stock = $this->stocks_model->getStockById($item_id);
    
    //     if ($stock) {
    //         $previous_quantity = $stock['quantity'];
    
    //         // Update stock quantity in the stocks table
    //         $this->db->set('quantity', $new_quantity);
    //         $this->db->where('item_id', $item_id);
    //         $update_result = $this->db->update('stocks');
    
    //         if ($update_result) {
    //             // Insert a record into stock_history to track the change
    //             $stock_history_data = array(
    //                 'item_id' => $item_id,
    //                 'previous_quantity' => $previous_quantity,
    //                 'new_quantity' => $new_quantity,
    //                 'updated_by' => $this->ion_auth->user()->row()->username
    //             );
    //             $this->db->insert('stock_history', $stock_history_data);
    
    //             // Return success response
    //             $response = array('status' => 'success', 'message' => 'Quantity updated successfully');
    //         } else {
    //             $response = array('status' => 'error', 'message' => 'Failed to update stock quantity');
    //         }
    //     } else {
    //         $response = array('status' => 'error', 'message' => 'Stock not found');
    //     }
    
    //     $this->output->set_content_type('application/json')->set_output(json_encode($response));
    // }
    
    public function getHistory()
{
    $item_id = $this->input->get('item_id');

    $this->db->where('item_id', $item_id);
    $this->db->order_by('updated_at', 'DESC');
    $query = $this->db->get('stock_history');

    if ($query->num_rows() > 0) {
        $result = array('status' => 'success', 'history' => $query->result_array());
    } else {
        $result = array('status' => 'error', 'message' => lang('no_history_found'));
    }

    $this->output->set_content_type('application/json')->set_output(json_encode($result));
}

}