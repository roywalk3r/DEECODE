
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Notes extends MY_Controller {
    /**
     * notes constructor.
     */
    public function __construct ()
    {
        parent::__construct ();
        // Load Notes Model
        $this->load->model ( 'notes_model' );
        // Load User Model
        // $this->load->model ('user_model');
        // Load Form Validation Library
        $this->load->library ( 'form_validation' );
        // Load Ion Auth Library
        $this->load->library ( 'ion_auth' );
        // Load Helper Language
        $this->load->helper('language');
        // Load Helper Date Format
        $this->load->helper('date_format');
        // Check user is logged in ?
        if ( !$this->ion_auth->logged_in () ) {
            if ($this->input->is_ajax_request()) {
                $next_link = urlencode("/notes");
                $result = array("status"=>"redirect", "message"=>site_url("auth/login?next=$next_link"));
                die(json_encode($result));
            }else{
                $next_link = urlencode(substr("$_SERVER[REQUEST_URI]", stripos("$_SERVER[REQUEST_URI]", "index.php")+9));
                redirect("auth/login?next=$next_link");
            }
        }
    }

    public function index()
    {
        $data['message']          = (validation_errors()) ? validation_errors() : $this->session->flashdata('message');
        $data['success_message']  = $this->session->flashdata('success_message');
        $meta['page_title']       = lang('notes');
        $data['page_title']       = lang('notes');

        $this->load->view ( 'templates/head' , $meta );
        $this->load->view ( 'templates/header' );
        $this->load->view ( 'notes/notes_view' );
        $this->load->view ( 'templates/footer' , $meta );
    }
    public function get_notes() {
        // Ensure this is an AJAX request
        if ($this->input->is_ajax_request()) {
            // Load the model
            $this->load->model('notes_model');
            // Fetch notes from the model
            $notes = $this->notes_model->get_all_notes();
            
            // Return JSON response
            header('Content-Type: application/json');
            echo json_encode(['notes' => $notes]);
            exit;
        } else {
            // If not an AJAX request, you might want to show an error or redirect
            show_error('No direct script access allowed');
        }
    }
    
 

    // Add a new note
    public function add()
    {
        $title = $this->input->post('title');
        $body = $this->input->post('body');
        $priority = $this->input->post('priority');

        $data = array(
            'title' => $title,
            'body' => $body,
            'priority' => $priority,
            'status' => 'pending',
            'user_id'=>  USER_ID,
        );

        if ($this->notes_model->add_note($data)) {
            echo json_encode([
                'success' => true,
                'csrfName' => $this->security->get_csrf_token_name(),
                'csrfHash' => $this->security->get_csrf_hash()
            ]);
                } else {
            echo json_encode(['success' => false, 'message' => 'Error adding note.']);
        }
    }

    // Update a note
    public function update() {
        // Get the ID, title, and body from the POST request
        $id = $this->input->post('id');
        $title = $this->input->post('title');
        $body = $this->input->post('body');
    
        // Ensure the user is logged in
        if (!$this->ion_auth->logged_in()) {
            echo json_encode(['success' => false, 'message' => 'You need to be logged in to update notes.']);
            return;
        }
    
        // Get current user ID
        $current_user_id = $this->ion_auth->get_user_id();
    
        // Check if ID is provided
        if ($id) {
            // Load the model if not already loaded
            $this->load->model('notes_model');
    
            // Fetch note to check ownership
            $note = $this->notes_model->get_note_by_id($id);
    
            if ($note) {
                if ($note->user_id == $current_user_id) {
                    // Proceed with update
                    $data = array(
                        'title' => $title,
                        'body' => $body,
                    );
    
                    if ($this->notes_model->update_note($id, $data)) {
                        echo json_encode(['success' => true, 'csrfName' => $this->security->get_csrf_token_name(), 'csrfHash' => $this->security->get_csrf_hash()]);
                    } else {
                        echo json_encode(['success' => false, 'message' => 'Failed to update note.']);
                    }
                } else {
                    // Note belongs to another user
                    echo json_encode(['success' => false, 'message' => 'You do not have permission to update this note.']);
                }
            } else {
                // Note not found
                echo json_encode(['success' => false, 'message' => 'Note not found.']);
            }
        } else {
            echo json_encode(['success' => false, 'message' => 'No note ID provided.']);
        }
    }
    
    
    //Update Status
    public function update_status() {
        $id = $this->input->post('id');
        $status = $this->input->post('status');
    
        if (empty($id) || empty($status)) {
            echo json_encode(array('success' => false, 'message' => 'Invalid input.'));
            return;
        }
    
        // Make sure to load the model
    
        // Update the status in the database
        if ($this->notes_model->update_status($id, $status)) {
            echo json_encode([
                'success' => true,
                'csrfName' => $this->security->get_csrf_token_name(),
                'csrfHash' => $this->security->get_csrf_hash()
            ]);
                } else {
            echo json_encode(array('success' => false, 'message' => 'Failed to update note status.'));
        }
    }
    
    

    // Delete a note
    public function delete_note() {
        $note_id = $this->input->post('id');
        
        // Ensure the user is logged in
        if (!$this->ion_auth->logged_in()) {
            echo json_encode(['success' => false, 'message' => 'You need to be logged in to delete notes.']);
            return;
        }
        
        // Get current user ID
        $current_user_id = $this->ion_auth->get_user_id();
        
        if ($note_id) {
            // Load the model if not already loaded
            $this->load->model('notes_model');
    
            // Fetch note to check ownership
            $note = $this->notes_model->get_note_by_id($note_id);
            
            if ($note) {
                if ($note->user_id == $current_user_id) {
                    // Proceed with deletion
                    $this->db->where('id', $note_id);
                    if ($this->db->delete('notes')) {
                        echo json_encode([
                            'success' => true,
                            'csrfName' => $this->security->get_csrf_token_name(),
                            'csrfHash' => $this->security->get_csrf_hash()
                        ]);
                    } else {
                        echo json_encode(['success' => false, 'message' => 'Failed to delete note.']);
                    }
                } else {
                    // Note belongs to another user
                    echo json_encode(['success' => false, 'message' => 'You do not have permission to delete this note.']);
                }
            } else {
                // Note not found
                echo json_encode(['success' => false, 'message' => 'Note not found.']);
            }
        } else {
            echo json_encode(['success' => false, 'message' => 'No note ID provided.']);
        }
    }
    
    
    
}