<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Orders extends MY_Controller {
    /**
     * Todo constructor.
     */
    public function __construct ()
    {
        parent::__construct ();
        // Load Todo Model
        $this->load->model ( 'orders_model' );
        // Load Form Validation Library
        $this->load->library ( 'form_validation' );
        // Load Ion Auth Library
        $this->load->library ( 'ion_auth' );
        // Load Helper Language
        $this->load->helper('language');
        // Load Helper Date Format
        $this->load->helper('date_format');
        // Check user is logged in ?
        if ( !$this->ion_auth->logged_in () ) {
            if ($this->input->is_ajax_request()) {
                $next_link = urlencode("/orders");
                $result = array("status"=>"redirect", "message"=>site_url("auth/login?next=$next_link"));
                die(json_encode($result));
            }else{
                $next_link = urlencode(substr("$_SERVER[REQUEST_URI]", stripos("$_SERVER[REQUEST_URI]", "index.php")+9));
                redirect("auth/login?next=$next_link");
            }
        }
    }

    public function index()
    {
        $data['message']          = (validation_errors()) ? validation_errors() : $this->session->flashdata('message');
        $data['success_message']  = $this->session->flashdata('success_message');
        $meta['page_title']       = lang('orders');
        $data['page_title']       = lang('orders');

        $this->load->view ( 'templates/head' , $meta );
        $this->load->view ( 'templates/header' );
        $this->load->view ( 'orders/orders' , $data );
        $this->load->view ( 'templates/footer' , $meta );
    }

    public function getData(){
        if (!$this->input->is_ajax_request()) {
            $result = array("status"=>"error", "message"=>lang("access_denied"));
            $this->output->set_content_type('application/json')->set_output(json_encode($result));
            return false;
        }
        $this->load->library('datatables');
        if ( $this->input->post('f') && $this->input->post('v') )
        {
            $v = $this->input->post('v');
            if( strpos($v, "~") === false ){
                $this->datatables->setFilter($this->input->post('f'), "=".$this->input->post('v'));
            }else{
                $this->datatables->setFilter($this->input->post('f'), $this->input->post('v'));
            }
        }
        $this->datatables
        ->setsColumns("name,phone_number,order_details,qty,date,status,amount,total_amount,company,id")
        ->select("id,name,phone_number,order_details,qty,date,status,amount,total_amount,company", false)
        // ->where("orders.user_id", USER_ID)
        ->from("orders");
        $this->output->set_content_type('application/json')->set_output( $this->datatables->generate() );
    }
    public function create()
    {
        if (!$this->input->is_ajax_request()) {
            $result = array("status" => "error", "message" => lang("access_denied"));
            $this->output->set_content_type('application/json')->set_output(json_encode($result));
            return false;
        }
    
        // Validation rules
        $this->form_validation->set_rules('order[name]', 'Name', 'xss_clean');
        $this->form_validation->set_rules('order[phone_number]', 'Phone Number', 'required|xss_clean');
        $this->form_validation->set_rules('order[order_details]', 'Order Details', 'required|xss_clean');
        $this->form_validation->set_rules('order[qty]', 'Quantity', 'required|integer|xss_clean');
        $this->form_validation->set_rules('order[date]', 'Date', 'required|xss_clean');
        $this->form_validation->set_rules('order[status]', 'Status', 'required|xss_clean');
        $this->form_validation->set_rules('order[amount]', 'Amount', 'required|numeric|xss_clean');
        $this->form_validation->set_rules('order[company]', 'Company', 'required|xss_clean');
    
        if ($this->form_validation->run() == true) {
            // Fetch data from POST request
            $order_data = $this->input->post('order'); 
            
            // Convert date format
            $order_data['date'] = date_JS_MYSQL($order_data['date']);
            
            // Assign current user ID
            $order_data['user_id'] = USER_ID;
    
            // Calculate total_amount as qty * amount
            $order_data['total_amount'] = $order_data['qty'] * $order_data['amount'];
    
            // Attempt to add order using model
            if ($this->orders_model->add($order_data)) {  
                $response = array("status" => "success", "message" => "Order added successfully.");
                $this->output->set_content_type('application/json')->set_output(json_encode($response));
                return;
            } else {
                // Error in adding to the model
                $response = array("status" => "error", "message" => "Failed to add order.");
                $this->output->set_content_type('application/json')->set_output(json_encode($response));
                return;
            }
        }
    
        // Validation errors
        if (validation_errors() || $this->ion_auth->errors()) {
            $response = array(
                "status" => "error",
                "message" => (validation_errors() ? validation_errors() : $this->session->flashdata('message')),
                "fields" => $this->form_validation->error_array()
            );
            $this->output->set_content_type('application/json')->set_output(json_encode($response));
        } else {
            // Reload the create view if validation fails
            $data['page_title'] = 'Create Order';
            $this->load->view('orders/create', $data);
        }
    }
    
    
  
   
 
    public function edit($id = false)
    {
        // Check if in demo mode
        if (VERSION == "DEMO") {
            $result = array("status" => "error", "message" => lang("is_demo"));
            $this->output->set_content_type('application/json')->set_output(json_encode($result));
            return;
        }
    
        // Get the ID from the request if not provided
        if (!$id && $this->input->get('id')) {
            $id = $this->input->get('id');
        }
    
        // Debugging: Log the ID
        log_message('debug', 'Edit ID: ' . $id);
    
        // Validate the ID and check permissions
        if (!$id || !($order = $this->orders_model->getByID($id)) || !$this->input->is_ajax_request()) {
            log_message('debug', 'Order Data: ' . print_r($order, true)); // Log order data
            log_message('debug', 'Is AJAX Request: ' . ($this->input->is_ajax_request() ? 'Yes' : 'No'));
            $result = array("status" => "error", "message" => "Access Denied, ID: $id, ORDER: $order");
            $this->output->set_content_type('application/json')->set_output(json_encode($result));
            return;
        }
    
        // Set form validation rules
        $this->form_validation->set_rules('order[name]', lang('name'), 'xss_clean');
        $this->form_validation->set_rules('order[phone_number]', lang('phone_number'), 'required|xss_clean');
        $this->form_validation->set_rules('order[order_details]', lang('order_details'), 'required|xss_clean');
        $this->form_validation->set_rules('order[qty]', lang('quantity'), 'required|integer|xss_clean');
        $this->form_validation->set_rules('order[date]', lang('date'), 'required|xss_clean');
        $this->form_validation->set_rules('order[status]', lang('status'), 'required|xss_clean');
        $this->form_validation->set_rules('order[amount]', lang('amount'), 'required|numeric|xss_clean');
        $this->form_validation->set_rules('order[company]', lang('company'), 'required|xss_clean');
    
        // Run validation and process data if valid
        if ($this->form_validation->run()) {
            $data = $this->input->post("order");
            $data['date'] = date_JS_MYSQL($data['date']); // Convert date format
            $data['total_amount'] = $data['qty'] * $data['amount'];
    
            if ($this->orders_model->update($id, $data)) {
                $result = array("status" => "success", "message" => "Order Edited Successfuly");
                $this->output->set_content_type('application/json')->set_output(json_encode($result));
            } else {
                $result = array("status" => "error", "message" => "Order Edit Failed");
                $this->output->set_content_type('application/json')->set_output(json_encode($result));
            }
            return;
        }
    
        // Handle errors
        if (validation_errors() || $this->ion_auth->errors()) {
            $result = array(
                "status" => "error",
                "message" => validation_errors() ?: $this->session->flashdata('message'),
                "fields" => $this->form_validation->error_array()
            );
            $this->output->set_content_type('application/json')->set_output(json_encode($result));
            return;
        }
        $data = array(
            'orders' => $order,
            'page_title' => 'Edit Order',
            // Add other data as needed
        );
        // If not an AJAX request, load the view for editing
        $data['page_title'] = "Edit Order";
     
        // Make sure to render the view correctly
        $this->load->view('orders/edit', $data);
    }
    
    
    public function delete($id = false)
    {
        // Check for demo mode
        if (VERSION == "DEMO") {
            $result = array("status" => "error", "message" => lang("is_demo"));
            $this->output->set_content_type('application/json')->set_output(json_encode($result));
            return false;
        }
    
        // Retrieve ID from query parameters if not provided
        if (!$id) {
            $id = $this->input->get('id');
        }
    
        // Check for valid ID and AJAX request
        if (!$id || !$this->input->is_ajax_request()) {
            $result = array("status" => "error", "message" => lang("access_denied"));
            $this->output->set_content_type('application/json')->set_output(json_encode($result));
            return false;
        }
    
        // Check user group permissions
        if (!$this->ion_auth->in_group(["admin", "superadmin"])) {
            $result = array("status" => "error", "message" => "You do not have permission to delete this order.");
            $this->output->set_content_type('application/json')->set_output(json_encode($result));
            return false;
        }
    
        // Proceed with deletion
        if ($this->orders_model->delete($id)) {
            $result = array("status" => "success", "message" => "Order deleted successfully, ID: $id");
            $this->output->set_content_type('application/json')->set_output(json_encode($result));
            return true;
        } else {
            $result = array("status" => "error", "message" => "Failed to delete order, ID: $id");
            $this->output->set_content_type('application/json')->set_output(json_encode($result));
            return false;
        }
    }
    

    // public function complete($id = false)
    // {
    //     if( VERSION == "DEMO" ){  // Action loaded only on release versions
    //         $result = array("status"=>"error", "message"=>lang("is_demo"));
    //         $this->output->set_content_type('application/json')->set_output(json_encode($result));
    //         return false;
    //     }
    //     if( $this->input->get('id') ){ $id = $this->input->get('id'); }
    //     if ( !$id || !$this->input->is_ajax_request()) {
    //         $result = array("status"=>"error", "message"=>lang("access_denied"));
    //         $this->output->set_content_type('application/json')->set_output(json_encode($result));
    //         return false;
    //     }
    //     if ( $this->todo_model->complete($id) )
    //     {
    //         $result = array("status"=>"success", "message"=>lang("todo_complete_success"));
    //         $this->output->set_content_type('application/json')->set_output(json_encode($result));
    //         return true;
    //     }
    // }

    // public function download_attachment($id = false){
    //     if( $this->input->get('id') ){$id = $this->input->get('id');}
    //     if ( !$id || !($todo = $this->todo_model->getByID($id)) ) {
    //         $this->session->set_flashdata('message', lang("access_denied"));
    //         redirect("/todo", 'refresh');
    //     }
    //     if( trim($todo->attachments) != "" ){
    //         $this->load->model('files_model');
    //         $files = $this->files_model->getByID(json_decode($todo->attachments));
    //         foreach ($files as $file) {
    //             $links[] = $file->link;
    //         }
    //         redirect('/files/download/'.implode(",", $links),'refresh');
    //     }else{
    //         $this->session->set_flashdata('message', lang("access_denied"));
    //         redirect("/todo", 'refresh');
    //     }
    // }
}

/* End of file todo.php */
/* Location: ./application/controllers/todo.php */
